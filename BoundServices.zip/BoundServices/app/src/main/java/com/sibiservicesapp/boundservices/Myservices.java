package com.sibiservicesapp.boundservices;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class Myservices extends Service {
    private final IBinder mbinder = new LocalServices();

    public static final int SERVERPORT = 9700;

    public static final String SERVER_IP = "203.192.211.51";
    public ClientThread clientThread;
    private Thread thread;
    private LinearLayout msgList;
    public Handler handler;
    public  String messgae;
    public Socket socket;

    @Override
    public IBinder onBind(Intent intent) {
        return mbinder;
    }

    public void sendmessage() {
        String clientMessage ="Hello";



    }

    public class LocalServices extends Binder
    {

        Myservices getServices()
        {

            return Myservices.this;
        }
    }
    public String getFirstMessage(){
        handler = new Handler();

        clientThread = new ClientThread();
        thread = new Thread(clientThread);
        thread.start();

        while (messgae == null)
        {
            return messgae;
        }

         return "Nothing";
        }

    class ClientThread implements Runnable {

        private BufferedReader input;

        @Override
        public void run() {

            try {
                InetAddress serverAddr = InetAddress.getByName( SERVER_IP );
                socket = new Socket( serverAddr, SERVERPORT );

                while (!Thread.currentThread().isInterrupted()) {

                    this.input = new BufferedReader( new InputStreamReader( socket.getInputStream() ) );
                    String message = input.readLine();
                    if (null == message || "Disconnect".contentEquals( message )) {
                        Thread.interrupted();
                        message = "Server Disconnected.";
                        MainActivity.showMessage( message );
                        break;
                    }
                    MainActivity.showMessage( message.trim() );


                }

            } catch (UnknownHostException e1) {
                e1.printStackTrace();
            } catch (IOException e1) {
                e1.printStackTrace();
            }

        }

        public void sendMessage(final String message) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (null != socket) {
                            PrintWriter out = new PrintWriter(new BufferedWriter(
                                    new OutputStreamWriter(socket.getOutputStream())),
                                    true);
                            out.println(message);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }

    }

    }

