package com.sibiservicesapp.boundservices;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {

    TextView textView;
    static Myservices myservices;
    boolean isBind = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_second );
        textView = findViewById( R.id.textv );
        Intent intent = new Intent( this,Myservices.class );
        bindService( intent,mConnection, Context.BIND_AUTO_CREATE );

    }

    public void getMesgFromServer(View view) {
        String message;
        message = myservices.getFirstMessage();
        textView.setText( message );

    }

    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Myservices.LocalServices localServices = (Myservices.LocalServices)service;
            myservices = localServices.getServices();
            isBind = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBind = false;
        }
    };

    @Override
    protected void onStop() {
        super.onStop();
        if (isBind)
        {
            unbindService( mConnection );
            isBind = false;
        }
    }

    public void sendmessage(View view) {
        String message ="Purches";
        if (null != myservices.clientThread) {
            myservices.clientThread.sendMessage(message);
        }
    }

    public static void showMessage(final String message) {
        myservices.handler.post( new Runnable() {
            @Override
            public void run() {
                Toast.makeText( myservices, message, Toast.LENGTH_SHORT ).show();
                return;

            }
        } );
    }


}
